# Kết quả phân tích bảng dữ liệu

Nguồn: application_gemma_long_demo.json
Model: v2_042e3aa1a886; selected=ridge; unit=VND/month.
Dòng nhập: 3; thành công: 3; lỗi: 0.

Độ khớp trên bảng nhập, không phải holdout độc lập:
{}

Lương VND/năm được chia 12; nhãn là trung điểm khoảng nếu đủ hai cận.
Không đổi ngoại tệ tự động. Lương trích bằng Gemma không dùng làm nhãn đánh giá.
Dòng trùng hoàn toàn vẫn có kết quả nhưng loại khỏi biểu đồ/metric.
Không có ngày đăng hợp lệ thì không tạo xu hướng theo thời gian.
Nhãn nguồn silver, gross/net có thể chưa rõ; gợi ý kỹ năng không phải tác động nhân quả.
